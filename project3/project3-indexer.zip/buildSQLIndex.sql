USE CS144;


create table Geom(Itemid INT,Latitude Varchar(50) NOT Null,Longitude Varchar(50));
insert into Geom(Itemid,Latitude,Longitude)select Itemid,Latitude,Longitude from Item where Latitude!='' And Longitude!='';
Alter table Geom add lat_long_point POINT not null;     
alter table Geom engine MyISAM;     
update Geom set lat_long_point=GeomFromText(concat('Point(',Latitude,' ',Longitude,')'));
create spatial index sp_index on Geom(lat_long_point);




 