package edu.ucla.cs.cs144;

import java.io.IOException;
import java.io.StringReader;
import java.io.File;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

public class Indexer {
    
    /** Creates a new instance of Indexer */
    public Indexer() {
                     }
 
 	//CREATE  IndexWriter
 	private IndexWriter indexWriter = null;

    public IndexWriter getIndexWriter(boolean create) throws IOException {
        File f1=new File("/var/lib/lucene/mansee/");
        
        if(f1.exists())
        {
            File[] contents = f1.listFiles();
            if (contents!=null)
            {
                for (File f : contents)
                    f.delete();
            }
        }    

        if (indexWriter == null) {
            Directory indexDir = FSDirectory.open(f1);
            IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_4_10_2, new StandardAnalyzer());
            indexWriter = new IndexWriter(indexDir, config);
        }
        return indexWriter;
   		}

    public void closeIndexWriter() throws IOException {
        if (indexWriter != null) {
            indexWriter.close();
        }
   }

   //now adding created index on the document with text fields in it
   /**
     * Adds an index for a single item.
     */
   

    public void rebuildIndexes() {
        try
        {
        Connection conn = null;

        // create a connection to the database to retrieve Items from MySQL
	       try {
	           conn = DbManager.getConnection(true);
	           } catch (SQLException ex) {
	               System.out.println(ex);
	               }
	// Initialize the index writer to overwrite the indexes.
            IndexWriter writer=getIndexWriter(true);
            ResultSet rs = getAllItems(conn);
		      if (rs != null)
		      {
			     while (rs.next()) 
			     {
				    Document doc = new Document();
  			           doc.add(new Field("Itemid", Integer.toString(rs.getInt("Itemid")), Field.Store.YES, Field.Index.NO));
  			           doc.add(new TextField("ItemName", rs.getString("Name"), Field.Store.YES));
  			           doc.add(new TextField("Description", rs.getString("Description"), Field.Store.YES));
 				       String itemCats = getCategories(conn, rs.getInt("Itemid"));
                     doc.add(new TextField("Category", itemCats, Field.Store.YES));
                     String fullSearchableText = rs.getString("Name") + " " + rs.getString("Description") + " " + itemCats;
 				       //System.out.println(Integer.toString(rs.getInt("Itemid"))+" Name ==> "+rs.getString("Name") + " Description=> " +rs.getString("Description") + "Category=>  " + itemCats);
                   doc.add(new TextField("content", fullSearchableText, Field.Store.NO));
  			       writer.addDocument(doc);
                } 
		     }

        // Close the index writer
        closeIndexWriter();


	/*
	 * Add your code here to retrieve Items using the connection
	 * and add corresponding entries to your Lucene inverted indexes.
         *
         * You will have to use JDBC API to retrieve MySQL data from Java.
         * Read our tutorial on JDBC if you do not know how to use JDBC.
         *
         * You will also have to use Lucene IndexWriter and Document
         * classes to create an index and populate it with Items data.
         * Read our tutorial on Lucene as well if you don't know how.
         *
         * As part of this development, you may want to add 
         * new methods and create additional Java classes. 
         * If you create new classes, make sure that
         * the classes become part of "edu.ucla.cs.cs144" package
         * and place your class source files at src/edu/ucla/cs/cs144/.
	 * 
	 */


        // close the database connection
	try {
	    conn.close();
	} catch (SQLException ex) {
	    System.out.println(ex);
	}

    }
    catch(IOException e)
    {
        System.out.print("ere");
    }
    catch(SQLException ex)
    {
        
    }
    }    


    //methods
    private static ResultSet getAllItems(Connection conn)
		{
			Statement stmt = null;  
			ResultSet rs = null;
	  	try 
	  	{
	  		stmt = conn.createStatement();
	 			rs = stmt.executeQuery("SELECT Itemid, Name, Description FROM Item");
	 		}
	 		catch (SQLException ex) 
			{
    		System.err.println("SQLException: " + ex.getMessage());
			} 
			return rs;
		}
		
		private static String getCategories(Connection conn, int Itemid)
		{
			Statement stmt = null;  
			String cats = "";
	  	try 
	  	{
	  		stmt = conn.createStatement();
	 			ResultSet rs = stmt.executeQuery("SELECT group_concat(Category separator ' ') as ItemCats FROM Category WHERE Itemid = '" + Itemid + "'");
	 			
 				if (rs.next())
 				{
 					cats = rs.getString("ItemCats");
 		  	}
	 		}
	 		catch (SQLException ex) 
			{
    		System.err.println("SQLException: " + ex.getMessage());
			} 
 		  
			return cats;
		}

    public static void main(String args[]) {
        Indexer idx = new Indexer();
        idx.rebuildIndexes();
    }   
}
