-- dropSQLIndex.sql --

USE CS144;

DROP TABLE IF EXISTS Geom;

