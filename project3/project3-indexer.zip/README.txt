�	Lucene Index is created on Itemid, Name, Description and Sellerid and UNION(Name, Description). This is to allow for more efficient text searching on the fields of the Item Table.

�	Also I have created spatial index sp_index to get latitude and longitude information. To drop SQL index and to avoid any errors, I have dropped table Geom in drop SQL index instead of dropping sp_index.

