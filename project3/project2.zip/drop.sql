Use CS144;
DROP TABLE IF EXISTS Bids,Category,Item,Bidder,Seller;