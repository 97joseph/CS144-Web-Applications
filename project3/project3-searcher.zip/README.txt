�	Lucene Indexes are created in folder mansee.

�	Spatial index sp_index is built on latitude and longitude. The program AuctionSearch.java has following methods:
1. basicSearch(query,numResultsToSkip,numResultsToReturn)
- This method, based on lucene indexes generated in folder mansee gets hits of type TopDocs and processes the results to get the itemids and names which contain query in their name,description.

2.spatialsearch
-Here I have created procedure which finds items within specified polygon and then the method gets intersection of itemids obtained from running procedure query on spatial index and hits obtained for query using lucene index.

3. getXMLDataForItemId
- returns XML data for specified item id.