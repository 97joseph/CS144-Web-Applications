package edu.ucla.cs.cs144;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.Date;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.CallableStatement;

import org.apache.lucene.document.Document;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.apache.lucene.search.*;
import org.apache.lucene.search.*;

import edu.ucla.cs.cs144.DbManager;
import edu.ucla.cs.cs144.SearchRegion;
import edu.ucla.cs.cs144.SearchResult;


/*java Timestamp class */
import java.sql.Timestamp;
import java.text.StringCharacterIterator;
import java.text.CharacterIterator;

public class AuctionSearch implements IAuctionSearch {

	/* 
         * You will probably have to use JDBC to access MySQL data
         * Lucene IndexSearcher class to lookup Lucene index.
         * Read the corresponding tutorial to learn about how to use these.
         *
	 * You may create helper functions or classes to simplify writing these
	 * methods. Make sure that your helper functions are not public,
         * so that they are not exposed to outside of this class.
         *
         * Any new classes that you create should be part of
         * edu.ucla.cs.cs144 package and their source files should be
         * placed at src/edu/ucla/cs/cs144.
         *
         */

	private IndexSearcher searcher = null;
	//private IndexSearcher searcher = null;
    private QueryParser parser = null;
	private Connection conn = null;
	public AuctionSearch()
	{
		try
		{
			searcher = new IndexSearcher(DirectoryReader.open(FSDirectory.open(new File("/var/lib/lucene/mansee/"))));
            		parser = new QueryParser("content", new StandardAnalyzer());
			//searcher = new IndexSearcher(System.getenv("LUCENE_INDEX"));
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		try 
		{
	  	conn = DbManager.getConnection(false);
		} 
		catch (SQLException ex) 
		{
	    System.out.println(ex);
		}
		
	}
	public SearchResult[] basicSearch(String query, int numResultsToSkip, 
			int numResultsToReturn) {

		// TODO: Your code here!
		System.out.println("In basic search");
		int n=numResultsToSkip+numResultsToReturn;
		TopDocs hits = getLuceneResults(query,n+1000);
		return processResults(hits, numResultsToSkip, numResultsToReturn);
		//return new SearchResult[0];
	}

	public SearchResult[] spatialSearch(String query, SearchRegion region,
			int numResultsToSkip, int numResultsToReturn) {
		// TODO: Your code here!
		int n=numResultsToSkip+numResultsToReturn;
		double lx=region.getLx();
		double ly=region.getLy();
		double rx=region.getRx();
		double ry=region.getRy();
		// so latitude for given id should be between lx and rx
		//longitude should be between ly and ry


		TopDocs hits = getLuceneResults(query,n+1000); //the the docs containing query words are returned
		ArrayList<String> ans= getSpatialResultSet(lx,ly,rx,ry);
		//System.out.println(ans.size());
		//System.out.println(hits);
		return getSpatialResults(hits,ans,numResultsToSkip,numResultsToReturn);
		//return new SearchResult[0];
	}
	public ArrayList<String> getSpatialResultSet(double lx, double ly, double rx, double ry)
	{
		ArrayList<String> ans=new ArrayList<String>();
		 try{
		Statement stmt = conn.createStatement();
				//creating procedure
		String coordinates = lx +" " + ly + "," + rx +" " + ly+"," + rx+" "+ ry + "," + lx+" " + ry + "," + lx+ " "+ ly;
		//System.out.println(coordinates);
		stmt.execute("DROP Procedure if exists multiquery");
		stmt.execute("CREATE PROCEDURE `multiquery`()" +
                   "BEGIN "+
                   "SET @poly = 'Polygon((" + coordinates + "))'; "+
                   "select Itemid,AsText(lat_long_point) FROM Geom where MBRContains(GeomFromText(@poly),lat_long_point);"+
                   // "select Itemid FROM Geom where MBRContains(GeomFromText(@poly),lat_long_point);"+           
                   "END");
		//System.out.println("Procedure created");
		
		CallableStatement cstmt=conn.prepareCall("{call multiquery()}");
		boolean hasMoreResultSets =cstmt.execute();
		//System.out.println(hasMoreResultSets);
		if(hasMoreResultSets)
		{

			ResultSet rs=cstmt.getResultSet();
			String ItemId;
			while (rs.next()) {
			ItemId = Integer.toString(rs.getInt("Itemid"));
			// System.out.println(ItemId);
			ans.add(ItemId);
		}
		}
		}
		catch (SQLException ex) {
			System.out.println(ex);
		};
		return ans;
	}

	public String getXMLDataForItemId(String itemId) {
		// TODO: Your code here!

		String xmlString = "<Item ItemID=\"" + itemId + "\">" + "\n";

		String SellerID,Country1, Name, Currently, First_Bid, Buy_Price, Number_of_Bids, Started, Ends, Description, Rating, Location, Country,Latitude,Longitude,Latitude1,Longitude1;
        SellerID = "";
        Name = "";
        Currently = "";
        First_Bid = "";
        Buy_Price = "";
        Number_of_Bids = "";
        Started =  "";
        Ends = "";
        Description = "";
        Rating = "";
        Location = "";
        Country1 = "";
        Country="";
        Latitude1="null";
        Longitude1="null";
        Latitude="";
        Longitude="";
        try{
		Statement stmt = conn.createStatement();

		ResultSet rs = stmt.executeQuery("SELECT * FROM Item WHERE Itemid ='" + itemId + "'");

		while (rs.next()) {
			SellerID = rs.getString("Sellerid");
			Name = rs.getString("Name");
			Currently = String.format("%.2f", rs.getFloat("Currently"));
			First_Bid = String.format("%.2f", rs.getFloat("First_bid"));
			/*if (rs.getFloat("Buy_Price") != null){
				Buy_Price = String.format("%.2f", rs.getFloat("Buy_Price"));
			}*/
			Buy_Price = String.format("%.2f", rs.getFloat("Buy_price"));
			Location = rs.getString("Location");
			Number_of_Bids = Integer.toString(rs.getInt("No_of_bids"));
			Started = rs.getTimestamp("Started").toString();
			Ends = rs.getTimestamp("Ends").toString();
			Description = rs.getString("Description").toString();
			Latitude1=rs.getString("Latitude");
			Country1=rs.getString("Country");
			//System.out.println("HI"+Latitude1+"HI");
			Longitude1=rs.getString("Longitude");
			}
					xmlString += "	<Name>" + forXML(Name) + "</Name>" + "\n";

					rs = stmt.executeQuery("SELECT * FROM Category WHERE Itemid='" + itemId + "'");

				while (rs.next()) {
				xmlString += "	<Category>" + forXML(rs.getString("Category")) + "</Category>" +"\n";
				}

				xmlString += "	<Currently>" + "$" + forXML(Currently) + "<Currently>" + "\n";

				if (!Buy_Price.equals("0.00")) {
				xmlString += "	<Buy_Price>" + "$" + forXML(Buy_Price) + "<Buy_Price>" + "\n";
				} 

				xmlString += "	<First_Bid>" + "$" + forXML(First_Bid) + "</First_Bid>" + "\n";

				xmlString += "	<Number_of_Bids>" + forXML(Number_of_Bids) + "</Number_of_Bids>" + "\n";

				xmlString += "	<Bids>";

				rs = stmt.executeQuery("SELECT * FROM Bids WHERE Itemid='" + itemId + "'");
				boolean notnull=true;
				
				while (rs.next()) {
				if(notnull==true){xmlString += "\n"; notnull=false;}
				xmlString = BidXMLHelper(xmlString, rs.getString("Bidderid"), rs.getTimestamp("Time").toString(),String.format("%.2f", rs.getFloat("Amount")));
				}

				xmlString += "</Bids>" + "\n";
				if(Latitude1.equals("") && Longitude1.equals(""))
				{	xmlString += "    "+"<Location>" + forXML(Location)+ "</Location>"+ "\n";
					
				}
				else
				xmlString += "    "+"<Location Latitude=\"" + forXML(Latitude1) +"\""+" Longitude=\"" + forXML(Longitude1)+"\">"+ forXML(Location)+ "</Location>"+ "\n";
				if(Country1==""){}
				else
				xmlString += "    "+"<Country>" + forXML(Country1)+ "</Country>"+ "\n";
				//xmlString += "  <Location>" + forXML(Location)+ "</Location"+ "\n";

				xmlString += "	<Started>" + forXML(convertTime(Started)) + "<Started>" + "\n";

				xmlString += "	<Ends>" + forXML(convertTime(Ends)) + "</Ends>" + "\n";

				rs = stmt.executeQuery("SELECT * FROM Seller WHERE Sellerid='" + SellerID + "'");
				int hi=0;
				String Rating1=null;
				while (rs.next()) {
				
				//xmlString += "	<Location>" + forXML(rs.getString("Location")) + "<Location>" + "\n";

				//xmlString += "	<Country>" + forXML(rs.getString("Country")) + "<Country>" + "\n";
				hi=rs.getInt("Rating");
				//System.out.println(hi);
				//Rating1 = Integer.toString(rs.getInt("Rating"));
				}

				if(hi!=0)
				{xmlString += "	<Seller " + "Rating=\"" + hi +"\""+ "  UserID=\"" + "\""+ forXML(SellerID) + "\" " +"/>"+ "\n";}
				else
				xmlString += "	<Seller " + "UserID=\"" + forXML(SellerID)+ "\"/>" + "\n";

				xmlString += "	<Description>" + forXML(Description) + "</Description>" + "\n";

				xmlString += "</Item>";
		


        } catch (SQLException ex) {};

        return xmlString;
	}







		
	
	public String echo(String message) {
		return message;
	}
	private SearchResult[] getSpatialResults(TopDocs hits, ArrayList<String> ans,int numResultsToSkip,int numResultsToReturn)
	{
		ScoreDoc[] hitsArray = hits.scoreDocs;

		if (numResultsToSkip > hitsArray.length)
		{
			return new SearchResult[0];
		}
		
		if (numResultsToReturn == 0)
		{
			numResultsToReturn = hitsArray.length;
		}
		
		ArrayList<SearchResult> temp = new ArrayList<SearchResult>();
		
    
    for(int i = numResultsToSkip; i < hitsArray.length; i++) 
        {
    	if (numResultsToReturn <= 0)
			{
				break;
			}
    	Document doc = null;
    	try
    	{
   			doc = getDocument(hitsArray[i].doc);
   		}
   		catch (Exception e)
   		{
   			System.out.println(e);
   		}
   		if(ans.contains(doc.get("Itemid")))
   		{temp.add(new SearchResult(doc.get("Itemid"), doc.get("ItemName")));
   		numResultsToReturn--;}
			
 		}
		SearchResult[] finalResults = new SearchResult[temp.size()];
		finalResults = temp.toArray(finalResults);
		
		return finalResults;
	}

	private TopDocs getLuceneResults(String query,int n)
	{
		if (query == null)
		{
			return null;
		}
		
		QueryParser parser = new QueryParser("content", new StandardAnalyzer());
		
		Query parsedQuery = null;
		
		
		try
		{
			parsedQuery = parser.parse(query);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		TopDocs hits = null;
		
		try
		{
			hits = searcher.search(parsedQuery,n);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		return hits;
	}

	public Document getDocument(int docId)
    throws IOException {
        return searcher.doc(docId);
    }


	private SearchResult[] processResults(TopDocs hits, int numResultsToSkip, int numResultsToReturn)
	{
		// obtain the ScoreDoc (= documentID, relevanceScore) array from topDocs
	ScoreDoc[] hitsArray = hits.scoreDocs;

		if (numResultsToSkip > hitsArray.length)
		{
			return new SearchResult[0];
		}
		
		if (numResultsToReturn == 0)
		{
			numResultsToReturn = hitsArray.length;
		}
		
		ArrayList<SearchResult> temp = new ArrayList<SearchResult>();
		
    
    for(int i = numResultsToSkip; i < hitsArray.length; i++) 
        {
    	if (numResultsToReturn <= 0)
			{
				break;
			}
    	Document doc = null;
    	try
    	{
   			doc = getDocument(hitsArray[i].doc);
   		}
   		catch (Exception e)
   		{
   			System.out.println(e);
   		}
   		temp.add(new SearchResult(doc.get("Itemid"), doc.get("ItemName")));
   		numResultsToReturn--;
			
 		}
		SearchResult[] finalResults = new SearchResult[temp.size()];
		finalResults = temp.toArray(finalResults);
		
		return finalResults;
	}



	public static String convertTime(String timeString)
    {
    	try
		  {
				SimpleDateFormat xmlformat = new SimpleDateFormat("MMM-dd-yy HH:mm:ss");
				SimpleDateFormat dbformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			        
				timeString = xmlformat.format(dbformat.parse(timeString));
			}
			catch(Exception pe)
			{
	    	System.out.println("ERROR: Cannot parse");
			} 
			
			return timeString;
    }


    public static String forXML(String aText){
    final StringBuilder result = new StringBuilder();
    final StringCharacterIterator iterator = new StringCharacterIterator(aText);
    char character =  iterator.current();
    while (character != CharacterIterator.DONE ){
      if (character == '<') {
        result.append("&lt;");
      }
      else if (character == '>') {
        result.append("&gt;");
      }
      else if (character == '\"') {
        result.append("&quot;");
      }
      else if (character == '\'') {
        result.append("&apos;");
      }
      else if (character == '&') {
         result.append("&amp;");
      }
      else if (character == '\\') {
      	result.append("\\");
      }
      else {
        //the char is not a special one
        //add it to the result as is
        result.append(character);
      }
      character = iterator.next();
    }
    return result.toString();
  }

	public String BidXMLHelper(String xmlString, String BidderID, String Time, String Amount) {

		String Rating = "";
		String Location ="";
		String Country = "";

		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Bidder WHERE Bidderid ='" + BidderID + "'");

			while (rs.next()) {
			Rating = Integer.toString(rs.getInt("Rating"));
			Location = rs.getString("Location");
			Country = rs.getString("Country");
		}

			xmlString += "		<Bid>" + "\n";
			xmlString += "			<Bidder " + "Rating=\"" + forXML(Rating) + "\"" +" UserID=\"" + forXML(BidderID) + "\">"+ "\n";
			xmlString += "				<Location>" + forXML(Location) + "</Location>" + "\n";
			xmlString += "				<Country>" + forXML(Country) + "</Country>" + "\n";
			xmlString += "			</Bidder>" + "\n";
			xmlString += "			<Time>" + forXML(convertTime(Time)) + "</Time>" + "\n";
			xmlString += "			<Amount>" + "$" + forXML(Amount) + "</Amount>" + "\n";
			xmlString += "		</Bid>" + "\n";

		} catch (SQLException ex) {};

		return xmlString;
	}
 

}

